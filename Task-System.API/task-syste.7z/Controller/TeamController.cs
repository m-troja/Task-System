﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Task_System.Log;
using Task_System.Model.DTO;
using Task_System.Model.DTO.Cnv;
using Task_System.Model.Request;
using Task_System.Service;

namespace Task_System.Controller
{
    [Authorize]
    [ApiController]
    [Route("api/v1/team")]
    public class TeamController : ControllerBase
    {
        private readonly IUserService _us;
        private readonly TeamCnv _teamCnv;
        private readonly ILogger<TeamController> _logger;
        private readonly ITeamService _ts;

        public TeamController(IUserService us, TeamCnv teamCnv, ILogger<TeamController> logger, ITeamService ts)
        {
            _us = us;
            _teamCnv = teamCnv;
            _logger = logger;
            _ts = ts;
        }

        [HttpGet("id/{id:int}")]
        public async Task<ActionResult<TeamDto>> GetTeamById(int id)
        {
            _logger.LogDebug($"Fetching team by id: {id}");
            var team = await _ts.GetTeamByIdAsync(id);
            if (team == null)
                return NotFound($"Team with id={id} not found");

            return Ok(_teamCnv.ConvertTeamToTeamDto(team));
        }

        [HttpGet("all")]
        public async Task<ActionResult<List<TeamDto>>> GetAllTeams()
        {
            _logger.LogDebug("Fetching all teams");
            var teams = await _ts.GetAllTeamsAsync();
            return Ok(_teamCnv.ConvertTeamsToTeamDtos(teams));
        }

        [HttpPost("create")]
        public async Task<ActionResult<TeamDto>> CreateTeam([FromBody] CreateTeamRequest req)
        {
            _logger.LogDebug($"Creating team with name: {req.Name}");
            var team = await _ts.AddTeamAsync(req);
            return Ok(_teamCnv.ConvertTeamToTeamDto(team));
        }

        [HttpGet("issues/{teamId:int}")]
        public async Task<ActionResult<List<IssueDto>>> GetIssuesByTeamId(int teamId)
        {
            _logger.LogDebug($"Fetching issues by teamId {teamId}");
            var issues = await _ts.GetIssuesByTeamId(teamId);
            return Ok(issues);
        }

        [HttpGet("users/{teamId:int}")]
        public async Task<ActionResult<List<UserDto>>> GetUsersByTeamId(int teamId)
        {
            _logger.LogDebug($"Fetching users by teamId {teamId}");
            var users = await _ts.GetUsersByTeamId(teamId); 
            return Ok(users);
        }
    }
}
