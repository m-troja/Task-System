﻿namespace Task_System.Model.DTO;

public class KeyDto
{
    public int Id { get; set; }
    public string KeyString { get; set; } = null!;
    public int ProjectId { get; set; }  
}
