﻿namespace Task_System.Model.Request;

public record LoginRequest(string email, string password)
{
}
