﻿namespace Task_System.Model.Request;

public record RenameIssueRequest(int id, string newTitle)
{
}
