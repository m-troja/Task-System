﻿namespace Task_System.Model.Request;

public record CreateTeamRequest(string Name)
{
}
