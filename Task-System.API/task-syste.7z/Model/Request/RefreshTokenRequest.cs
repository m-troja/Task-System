﻿namespace Task_System.Model.Request
{
    public record RefreshTokenRequest(int UserId, string RefreshToken)
    {
    }
}
