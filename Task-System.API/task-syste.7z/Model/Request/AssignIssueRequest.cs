﻿namespace Task_System.Model.Request;

public record AssignIssueRequest(int IssueId, int AssigneeId)
{
}
