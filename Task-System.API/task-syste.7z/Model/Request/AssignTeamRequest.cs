﻿namespace Task_System.Model.Request;

public record AssignTeamRequest(int IssueId, int TeamId)
{
}
