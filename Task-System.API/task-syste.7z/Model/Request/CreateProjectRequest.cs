﻿namespace Task_System.Model.Request;

public record CreateProjectRequest(string shortName, string? description)
{
}
