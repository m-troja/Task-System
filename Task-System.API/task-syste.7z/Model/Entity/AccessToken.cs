﻿namespace Task_System.Model.Entity;

public record AccessToken
(
    string Token,
    DateTime Expires
){}