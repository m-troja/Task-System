﻿namespace Task_System.Model.Entity;

public enum ActivityType
{
    CREATED_ISSUE,
    CREATED_COMMENT,
    UPDATED_ASSIGNEE,
    UPDATED_PRIORITY,
    UPDATED_STATUS,
}
