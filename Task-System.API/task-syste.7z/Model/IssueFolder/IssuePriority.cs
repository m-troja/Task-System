﻿namespace Task_System.Model.IssueFolder
{
    public enum IssuePriority
    {
        LOW,
        NORMAL,
        HIGH,
        CRITICAL
    }
}
