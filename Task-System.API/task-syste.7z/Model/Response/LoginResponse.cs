﻿namespace Task_System.Model.Response;

public record LoginResponse(ResponseType responseType, string accessToken)
{
}
