﻿namespace Task_System.Model.Response
{
    public record Response(ResponseType responseType , string message)
    {
    }
}
