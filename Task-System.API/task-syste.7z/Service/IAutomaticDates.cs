﻿namespace Task_System.Service
{
    public interface IAutomaticDates
    {
        DateTime CreatedAt { get; set; }
        DateTime? UpdatedAt { get; set; }
    }
}
