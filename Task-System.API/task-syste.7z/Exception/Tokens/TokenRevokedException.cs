﻿namespace Task_System.Exception.Tokens;

public class TokenRevokedException(string message) : System.Exception(message) 
{
}
