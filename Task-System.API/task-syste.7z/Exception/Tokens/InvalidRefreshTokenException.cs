﻿namespace Task_System.Exception.Tokens;

public class InvalidRefreshTokenException(string message) : System.Exception(message) 
{
}
