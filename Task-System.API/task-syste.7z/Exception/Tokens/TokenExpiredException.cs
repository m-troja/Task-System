﻿namespace Task_System.Exception.Tokens;

public class TokenExpiredException(string message) : System.Exception(message) 
{
}
