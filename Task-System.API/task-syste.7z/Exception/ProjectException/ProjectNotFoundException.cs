﻿namespace Task_System.Exception.ProjectException
{
    public class ProjectNotFoundException(string Message) : System.Exception(Message)
    {
    }
}
