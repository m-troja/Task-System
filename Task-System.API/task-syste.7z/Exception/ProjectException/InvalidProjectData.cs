﻿namespace Task_System.Exception.ProjectException;

public class InvalidProjectData(string Message) : System.Exception(Message)
{
}
