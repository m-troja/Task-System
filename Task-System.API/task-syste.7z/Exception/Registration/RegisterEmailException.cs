﻿namespace Task_System.Exception.Registration;

public class RegisterEmailException(string message) : System.Exception(message) 
{
}
