﻿namespace Task_System.Exception.IssueException;

public class IssueCreationException(string message) : System.Exception(message)
{
}
