﻿namespace Task_System.Exception.IssueException;

public class IssueNotFoundException(string message) : System.Exception(message)
{
}
