﻿namespace Task_System.Exception.UserException
{
    public class UserAlreadyExistsException(string Message) : System.Exception(Message)
    {
    }
}
