﻿namespace Task_System.Exception.UserException
{
    public class UserDisabledException(string Message) : System.Exception(Message)
    {
    }
}
