﻿namespace Task_System.Exception.UserException
{
    public class UserNotFoundException(string Message) : System.Exception(Message)
    {
    }
}
