﻿namespace Task_System.Exception.Error
{
    public record ErrorResponse(ErrorType ErrorType, string Message)
    {
    }
}
